﻿namespace Task4.Entities
{
    public abstract class Entity : IEntity
    {
        public uint? ID { get; set; }

        public Entity() { ID = null; }

        public abstract void Write();
        public abstract void Read();
    }
}
