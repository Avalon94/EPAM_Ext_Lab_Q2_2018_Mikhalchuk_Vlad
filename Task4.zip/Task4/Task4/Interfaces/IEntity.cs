﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task4
{
    public interface IEntity
    {
        uint? ID { get; set; }

        void Write();
        void Read();
    }
}