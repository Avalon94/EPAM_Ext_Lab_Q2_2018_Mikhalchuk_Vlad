﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task4
{
    public class Repository
    {
        public List<User> Users { get; set; }

        public List<Role> Roles { get; set; }

        public void WriteAll() { }
        /// <summary>
        /// Загрузить все данные из базы
        /// </summary>
        public void ReadAll() { }
        /// <summary>
        /// Сохранить одну записть в базе
        /// </summary>
        /// <param name="entity">Сущность, состояние которой необходимо сохранить.</param>
        public void Write(IEntity entity) { }
        /// <summary>
        /// Считать из базы состояние ранее загруженной сущности.
        /// </summary>
        /// <param name="entity">Сущность, состояние которой необходимо пересчитать</param>
        public void Read(IEntity entity)
        {
            if (entity.ID == null)
                throw new Exceptions.NullIDException();
        }
        /// <summary>
        /// Считать из базы сущность
        /// </summary>
        /// <param name="id">ID записи, которую необходимо считать</param>
        /// <param name="entity">Ссылка, в которую будет произведено считывание из базы</param>
        public void Read(uint id, IEntity entity) { }

    }
}
