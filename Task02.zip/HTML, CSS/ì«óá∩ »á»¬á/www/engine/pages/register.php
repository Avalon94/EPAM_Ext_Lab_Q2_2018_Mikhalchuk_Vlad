<script>
    $(function() {
       $("#button")
               .button()
               .click(
                function() {
                    register();                    
                });
    });
    
    function register(){
	
	var data = 'login='+$("input[name='login']").val();
	    data=data+'&password='+$("input[name='password']").val();
            data=data+'&email='+$("input[name='email']").val();
            data=data+'&firstname='+$("input[name='firstname']").val();
            data=data+'&lastname='+$("input[name='lastname']").val();
            data=data+'&city='+$("input[name='city']").val();
            data=data+'&url='+$("input[name='url']").val();
            data=data+'&description_site='+$("input[name='description_site']").val();
            data=data+'&subscribers='+$("input[name='subscribers']").val();
            
            $.ajax({      
                    type: "POST",
                    url: "engine/library/_register.php",		      
                    data: data,	
                    cache: false,
                    beforeSend: function(html){$("#loading").fadeIn('slow'); },
                    success:function(html){
                            $("#place_to_message").html(html);
                            $("#loading").fadeOut('slow');
                  }
            });   
           
    }
</script>
<div align="center" class="ui-widget-content" style="width: 10%; max-width:1200px;  min-width:300px;margin:10px auto;" >
            <h3>Регистрация партнера:</h3>
            
            
                <table class="ui-widget-content">
                    <tr>
                        <td>Логин:</td>
                        <td><input name="login" class='text ui-widget-content ui-corner-all' value="" size=30  ></td>
                    </tr>
                    <tr>
                        <td>Пароль:</td>
                        <td><input type="password" name="password" class='text ui-widget-content ui-corner-all' value="" size=30 ></td>
                    </tr>
                    <tr>
                        <td>Email:</td>
                        <td><input name="email" class='text ui-widget-content ui-corner-all' value="" size=30  ></td>
                    </tr>
                    <tr>
                        <td>Имя:</td>
                        <td><input name="firstname" class='text ui-widget-content ui-corner-all' value="" size=30  ></td>
                    </tr>
                    <tr>
                        <td>Фамилия:</td>
                        <td><input name="lastname" class='text ui-widget-content ui-corner-all' value="" size=30  ></td>
                    </tr>
                    <tr>
                        <td>Город:</td>
                        <td><input name="city" class='text ui-widget-content ui-corner-all' value="" size=30  ></td>
                    </tr>
                     <tr>
                        <td>Сайт:</td>
                        <td><input name="url" class='text ui-widget-content ui-corner-all' value="" size=30  ></td>
                    </tr>
                    <tr>
                        <td>Описание сайта:</td>
                        <td><input name="description_site" class='text ui-widget-content ui-corner-all' value="" size=30  ></td>
                    </tr>
                    <tr>
                        <td>Количество подписчиков (если есть):</td>
                        <td><input name="subscribers" class='text ui-widget-content ui-corner-all' value="" size=30  ></td>
                    </tr>
                </table>
                 <button id="button" >Регистрация</button>
            
          
</div>