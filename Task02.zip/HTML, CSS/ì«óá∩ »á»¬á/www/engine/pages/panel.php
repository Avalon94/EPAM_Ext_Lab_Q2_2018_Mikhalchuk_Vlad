<h3 align="center" class="ui-widget-header">Панель управления</h3>
            
           <div class='ui-widget-content' style='padding: 10px; margin: 10px 10px;' >
               текст с описанием раздела
            </div>
            <p>Элементы интерфейса</p>
        </div>   