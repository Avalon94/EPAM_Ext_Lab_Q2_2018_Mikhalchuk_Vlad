<h3 align="center" class="ui-widget-header">Партнеры</h3>
            
<div class='ui-widget-content' style='padding: 10px; margin: 10px 10px;' >
               текст с описанием раздела
</div>
 <style>
	div#tab { width: 98%; max-width:1200px; min-height: 30px;}
	div#tab table { margin: 1em 0; border-collapse: collapse; width: 100%; }
	div#tab table td, div#tab table th {border: 1px solid #eee; padding: .6em 10px; text-align: center; }
</style>
<div id="tab" align="center">
<table style='width: auto;' class='ui-widget ui-widget-content'>
		<thead>
			<tr class='ui-widget-header '>
				<th>Логин</th>
				<th>Email</th>
                                <th>Имя</th>
                                <th>Фамилия</th>
                                <th>Город</th>
                                <th>Сайт</th>
			</tr>
		</thead>
		<tbody>
                    <?php
                    $ResultQuery = mysql_query ("SELECT * FROM users WHERE (level='Партнер') ");
                    while($Result=mysql_fetch_array($ResultQuery)){ 
                            $id=$Result[0];                            
                            $login=$Result[1];
                            $email=$Result[3];
                            $firstname= get_data_affeliate($id,'firstname');
                            $lastname= get_data_affeliate($id,'lastname');
                            $city= get_data_affeliate($id,'city');
                            $url= get_data_affeliate($id,'url');
                            $description_site= get_data_affeliate($id,'description_site');
                            $subscribers= get_data_affeliate($id,'subscribers');
                            
                            echo "<tr>";
                            
                            echo "<td>";
                            echo $login;
                            echo "</td>";
                            
                            echo "<td>";
                            echo $email;
                            echo "</td>";
                            
                            echo "<td>";
                            echo $firstname;
                            echo "</td>";
                            
                            echo "<td>";
                            echo $lastname;
                            echo "</td>";
                            
                            echo "<td>";
                            echo $city;
                            echo "</td>";
                            
                            echo "<td>";
                            echo "<a target='_blank' href='".$url."' title='".$description_site."'>".$url."</a>";
                            echo "</td>";
                            
                            echo "</tr>";
                            
                    }
                    ?>
		</tbody></table>
		</div>
</div>   