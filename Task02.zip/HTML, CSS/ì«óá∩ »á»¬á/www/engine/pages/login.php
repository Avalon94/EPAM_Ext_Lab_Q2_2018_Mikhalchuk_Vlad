 <div align="center" class="ui-widget-content" style="width: 10%; max-width:1200px;  min-width:300px;margin:10px auto;" >
            <h3>Вход в партнерку:</h3>
            
            <form method="POST" action="/">
                <table class="ui-widget-content">
                    <tr>
                        <td>Логин:</td>
                        <td><input name="login" class='text ui-widget-content ui-corner-all' value="" size=30  ></td>
                    </tr>
                    <tr>
                        <td>Пароль:</td>
                        <td><input type="password" name="password" class='text ui-widget-content ui-corner-all' value="" size=30 ></td>
                    </tr>
                </table>
                 <input id="button"  type="submit" value="Войти"></input>
            </form>
          
</div>