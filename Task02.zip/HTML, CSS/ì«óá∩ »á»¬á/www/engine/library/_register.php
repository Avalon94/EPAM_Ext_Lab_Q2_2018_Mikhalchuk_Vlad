<?php 
require_once 'config.php';
require_once 'functions.php';

$user = new stdClass(); // Создаём объект
foreach( $_REQUEST as $key=>$val )  $user->$key = sanitize($val); //получаем переменные 

$sql="SELECT 
        *
        FROM 
            users
    WHERE 
        (login='$user->login') OR (email='$user->email')";
						
$result = mysql_query($sql);

if (mysql_num_rows($result)){
    say_error_animated("Ошибка: ", "Такой партнер уже зарегистрирован!");
    exit();
}

$user->password=md5($user->password);

$sql="INSERT INTO 
        users
        VALUES(
         NULL,
         '$user->login',
         '$user->password',    
         '$user->email',
         'Партнер'             
        )";						
$result = mysql_query($sql) or die(say_error_animated("Ошибка: ", mysql_error()));

$sql="SELECT  
            *
        FROM 
            users
        WHERE 
            (login='$user->login') AND (email='$user->email')";
						
$result = mysql_query($sql);
$user->id_user=mysql_result($result ,0,'id'); 

$sql="INSERT INTO 
            affeliates
        VALUES(
            NULL,
            '$user->id_user',
            '$user->firstname',    
            '$user->lastname',
            '$user->city', 
            '$user->url', 
            '$user->description_site',  
            '$user->subscribers'    
        )";						
$result = mysql_query($sql) or die(say_error_animated("Ошибка: ", mysql_error()));

if ($result)
    alert_animated("Внимание! ",$user->firstname.", Вы успешно зарегистрированы!");