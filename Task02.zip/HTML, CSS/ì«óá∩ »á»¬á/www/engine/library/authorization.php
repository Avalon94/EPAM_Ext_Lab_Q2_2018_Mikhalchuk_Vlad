<?php 
session_start(); //обязательно в самом начале

require_once('config.php'); 
require_once('functions.php');  

$level = "level";
$url_success = "/engine/";

if (isset($_GET['accesscheck'])) $_SESSION['PrevUrl'] = $_GET['accesscheck'];

//обработка отправки данных из формы
if (isset($_POST['login'])) {

	//получаем из формы
	$login=  sanitize($_POST['login']);
	$password=md5(sanitize($_POST['password']));	
        

	//создаем защищенный запрос для поиска логина и пароля в БД
	$query=sprintf(
			"SELECT 
                            login, password, level 
                         FROM 
                            users 
                         WHERE 
                            login=%s AND password=%s",
				GetSQLValueString($login, "text"), 
				GetSQLValueString($password, "text")
			); 

	$result = mysql_query($query) or die(mysql_error());  //делаем запрос к БД
  	$count = mysql_num_rows($result);  //получаем количество найденных пользователей
        
	
	//Если найден пользователь, т.е. есть такая пара логин пароль
	if ($count===1) {
           
           
                // для совместимости с версиями PHP проверяем версию и только потом обновляем сессию
                if (PHP_VERSION >= 5.1) session_regenerate_id(true); else session_regenerate_id(); //и запускаем сессию
	 	
		$_SESSION['MM_Username'] = $login; //записываем данные в сессию
            
                $ResultQuery = mysql_query ("SELECT * FROM `users` WHERE (login='$login') ");
                while($Result=mysql_fetch_array($ResultQuery)){                        
                        $level=$Result[4];
                }
                

                $_SESSION['MM_UserGroup'] = $level; //записываем данные в сессию 
		  
		if (isset($_SESSION['PrevUrl'])) //и если установлена переменная сессии
                    $url_success = $_SESSION['PrevUrl'];//получаем адрес админки
                
		header("Location: " . $url_success ); //переадресовываем в админку
                   
	} else //если такого пользователя нет, то выводим ошибку!
           // echo "<div id='error_message'><div align='left' class='ui-widget' style='width: 90%; max-width:1200px; margin: 20px auto; padding: 10px;'><div class='ui-state-error ui-corner-all' style='width: 90%; max-width:1200px; margin: 0px auto; padding: 10 .7em;'><p><span class='ui-icon ui-icon-alert' style='float: left; margin-right: .3em;'></span><strong>Ошибка: </strong>Неправильно введена пара логин/пароль. </p></div></div></div>";
        say_error("Ошибка: ","Неправильно введена пара логин/пароль.");

}