<?php
/////////////////////////////////////////////////////////////
///              функции скрипта
////////////////////////////////////////////////////////////
//
//
//---------------  защита передаваемых данных в БД-------------
// пример использования
//  $_POST = sanitize($_POST);
function cleanInput($input) {

  $search = array(
    '@<script[^>]*?>.*?</script>@si',   // javascript
    '@<[\/\!]*?[^<>]*?>@si',            // HTML теги
    '@<style[^>]*?>.*?</style>@siU',    // теги style
    '@<![\s\S]*?--[ \t\n\r]*>@'         // многоуровневые комментарии
  );

    $output = preg_replace($search, '', $input);
    return $output;
}
  
function sanitize($input) {
    if (is_array($input)) {
        foreach($input as $var=>$val) {
            $output[$var] = sanitize($val);
        }
    }
    else {
        if (get_magic_quotes_gpc()) {
            $input = stripslashes($input);
        }
        $input  = cleanInput($input);
        $output = mysql_real_escape_string($input);
    }
    return $output;
}

//*****Функция решающая проблему совместимости использования кавычек в запросе разных версий PHP*******
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
	  if (PHP_VERSION < 6) $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
	
	  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);
	
	  switch ($theType) {
	    case "text":
	      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
	      break;    
	    case "long":
	    case "int":
	      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
	      break;
	    case "double":
	      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
	      break;
	    case "date":
	      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
	      break;
	    case "defined":
	      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
	      break;
	  }
	  return $theValue;
}

// *************************Доступ к странице: Полный доступ или нет доступа*********************************************
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // Для безопасности сначала пользователь не авторизован
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && false) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

// *************************Сообщение "ВНИМАНИЕ" *********************************************
function alert($head, $body) { 

 echo '<div class="ui-widget"  style="margin: 20px; ">
	<div class="ui-state-highlight ui-corner-all" style="margin-top: 20px; padding: 1.7em;">
		<span class="ui-icon ui-icon-info" style="float: left; margin-right: .3em;"></span>
	<strong >'.$head.' </strong> '.$body.'
	</div>
	</div>';  
return true;
}


// *************************Сообщение "ВНИМАНИЕ" ******** анимированное*************************************
function alert_animated($head, $body) { 
echo "<script>";
echo '$("';
echo"<div align='left' id='info_message'>";
echo "<div class='ui-widget' style='width: 90%; max-width:1200px; margin: 20px auto; padding: 10px;'><div class='ui-state-highlight ui-corner-all' style='width: 90%; max-width:1200px; margin: 0px auto; padding: 10 .7em;'><p><span class='ui-icon ui-icon-info' style='float: left; margin-right: .3em;'></span><strong>";
echo $head;
echo "</strong>";
echo $body;
echo'</p></div></div></div>").appendTo("#place_to_message");';
echo "$('#info_message').hide();";
echo "$('#info_message')";
echo "		.fadeIn(3000,";
echo "	function(){})";
echo "		.fadeOut(6000, ";
echo "		function(){";
echo "				$(this).remove();";
echo "				});";
echo "</script>";
 
return true;
}
// *************************Сообщение "ОШИБКА *********************************************
function say_error($head, $body) { 
echo "<div align='left' id='error_message'><div class='ui-widget' style='width: 90%; max-width:1200px; margin: 20px auto; padding: 10px;'><div class='ui-state-error ui-corner-all' style='width: 90%; max-width:1200px; margin: 0px auto; padding: 10 .7em;'><p><span class='ui-icon ui-icon-alert' style='float: left; margin-right: .3em;'></span><strong>".$head."</strong>".$body."</p></div></div></div>";
return true;
}

// *************************Сообщение "ОШИБКА" ******** анимированное*************************************
function say_error_animated($head, $body) { 

echo "<script>";
echo '$("';
echo"<div align='left' id='error_message'>";
echo "<div class='ui-widget' style='width: 90%; max-width:1200px; margin: 20px auto; padding: 10px;'><div class='ui-state-error ui-corner-all' style='width: 90%; max-width:1200px; margin: 0px auto; padding: 10 .7em;'><p><span class='ui-icon ui-icon-alert' style='float: left; margin-right: .3em;'></span><strong>";
echo $head;
echo "</strong>";
echo $body;
echo'</p></div></div></div>").appendTo("#place_to_message");';
echo "$('#error_message').hide();";
echo "$('#error_message')";
echo "		.fadeIn(3000,";
echo "	function(){})";
echo "		.fadeOut(6000, ";
echo "		function(){";
echo "				$(this).remove();";
echo "				});";
echo "</script>";

return true;
}

// *************************Получение данных партнера*************************************
function get_data_affeliate($id,$data) { 
    	$ResultQuery=mysql_query ("SELECT 
					$data
		  		  FROM
		  			affeliates 				  	
		  		 WHERE 
				    id_user='$id'");

	return mysql_result($ResultQuery,0,$data);
}