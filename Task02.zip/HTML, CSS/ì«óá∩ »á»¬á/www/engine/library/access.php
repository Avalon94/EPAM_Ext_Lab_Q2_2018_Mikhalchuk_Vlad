<?php 
session_start();

/////////////////////////////Устанавливаем переменные//////////////////////////////////////////////////
require_once('config.php');
require_once('functions.php'); 
 
$AuthorizedUsers = "Менеджер,Партнер,Клиент"; //Уровни доступа которым открыта админка
$MainURL = "../";
$logoutAction = "index.php?doLogout=true";  // ссылка кнопки выход

if ($_SERVER['QUERY_STRING'] != "")  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']); 

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Проверяем нажата ли кнопка "выход"
if ($_GET['doLogout'] == "true"){
	//для полного выхода пользователя нужно очистить все переменные
	unset($_SESSION['MM_Username']);
	unset($_SESSION['MM_UserGroup']);
	unset($_SESSION['PrevUrl']);

	//когда все переменные сессии освобождены переадресовываем на главную	
	header("Location: $MainURL");
	exit;	 
}

// Если пользователь не авторизован
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$AuthorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  
	$qsChar = "?";
	$Referrer = $_SERVER['PHP_SELF'];

	if (strpos($MainURL, "?")) $qsChar = "&";

	if (strlen($_SERVER['QUERY_STRING']) > 0) 
	$Referrer .= "?" . $_SERVER['QUERY_STRING'];
	$MainURL = $MainURL. $qsChar . "accesscheck=" . urlencode($Referrer);
	
	header("Location: ". $MainURL); 	
	exit;
}

// получаем необходимые переменные
$CurrentLogin=$_SESSION['MM_Username']; // берем текущий логин из сесcии
