<?php
/////////////////////////////////////////////////////////////////////////////
//                        ПАНЕЛЬ УПРАВЛЕНИЯ
////////////////////////////////////////////////////////////////////////////

require_once 'library/access.php'; 
require_once 'library/config.php';
require_once 'library/functions.php';

$user = new stdClass(); // Создаём объект
foreach( $_REQUEST as $key=>$val )  $user->$key = sanitize($val); //получаем переменные 
/*
$sql="SELECT 
            *
        FROM 
            users
        WHERE 
            login='$user->login'";
						
$result = mysql_query($sql);

$user->password2=mysql_result($result ,0,'password'); 
$user->password=md5($user->password);
*/
?>
<HTML>
<HEAD>
    <title>Панель управления</title>
<meta charset="utf-8">
<link href="css/trontastic/jquery-ui.css" rel="stylesheet" type="text/css"/>  
<script src="js/jquery.js"></script>
<script src="js/jquery-ui.js"></script>
</HEAD>    
<BODY   style='background:transparent url(css/trontastic/images/ui-bg_diagonals-small_50_262626_40x40.png) repeat 0 0 scroll;'>
 <div>
 <div style="float: left;  padding: 10px; margin-top: 50px;">
    <script>
    $(function() {
      $( "#menu" ).menu();
    });
    </script>
  <style>
    .ui-menu { width: 200px; }
    p {padding: 10px;}
  </style>
  
 <ul id="menu">
  <li><a href="index.php">Панель управления</a></li>
  <li>
    <a href="#"><span class="ui-icon ui-icon-person"></span>Пользователи</a>
    <ul>
        <li><a href="index.php?p=affeliates">Партнеры</a></li>
      <li><a href="#">Клиенты</a></li>
      <li><a href="#">Менеджеры</a></li>
    </ul>
  </li>  
  <li><a href="<?php echo $logoutAction ?>"><span class="ui-icon ui-icon-power"></span>Выход</a></li>
</ul>
   </div>

    <div style="float: left" class="ui-widget-content" style="width:90%; max-width:1200px;  min-width:900px;" >
        <div style="width: 900px; height: 700px; ">
        <?php  

        switch ($_GET['p']) {
            case "panel":           require_once 'pages/panel.php'; break;
            case "affeliates":        require_once 'pages/affeliates.php'; break;
            default:                require_once 'pages/panel.php'; break;						
        }

        ?>
        
        </div>
 
 </div>   
</BODY>    
</HTML>