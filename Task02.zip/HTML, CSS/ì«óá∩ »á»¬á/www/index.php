<?PHP
/////////////////////////////////////////////////////////////////////////////
//                        форма входа
////////////////////////////////////////////////////////////////////////////
require_once 'engine/library/authorization.php'; //обработка формы входа и установка стиля как у админа 
?>

<HTML>
    <HEAD>
        <title>Партнерская программа Мастер PHP</title>
        <meta charset="utf-8">
        <link href="engine/css/trontastic/jquery-ui.css" rel="stylesheet" type="text/css"/>  
        <script src="engine/js/jquery.js"></script>
        <script src="engine/js/jquery-ui.js"></script>
        <script>
            $(function() {
                $("#button").button();
            });
        </script>
    </HEAD>    
    <BODY align="center"  style='background:transparent url(engine/css/trontastic/images/ui-bg_diagonals-small_50_262626_40x40.png) repeat 0 0 scroll;'>
        <div  class="place_to_message" id="place_to_message"></div>
       
 <?php  
 
switch ($_GET['p']) {
    case "login":           require_once 'engine/pages/login.php'; break;
    case "register":        require_once 'engine/pages/register.php'; break;
    default:                require_once 'engine/pages/login.php'; break;						
}

?>
       

</BODY>    
</HTML>