-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Янв 24 2014 г., 12:45
-- Версия сервера: 5.5.25
-- Версия PHP: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `masterphp`
--

-- --------------------------------------------------------

--
-- Структура таблицы `affeliates`
--

CREATE TABLE IF NOT EXISTS `affeliates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL COMMENT 'Имя',
  `lastname` varchar(255) NOT NULL COMMENT 'Фамилия',
  `city` varchar(255) NOT NULL COMMENT 'город',
  `url` varchar(255) NOT NULL COMMENT 'адрес сайта',
  `description_site` text NOT NULL COMMENT 'описание сайта',
  `subscribers` int(11) NOT NULL COMMENT 'количество подписчиков',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Хранение данных о партнерах' AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `affeliates`
--

INSERT INTO `affeliates` (`id`, `id_user`, `firstname`, `lastname`, `city`, `url`, `description_site`, `subscribers`) VALUES
(4, 5, 'test', 'test', 'test', 'test', 'test', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `managers`
--

CREATE TABLE IF NOT EXISTS `managers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL COMMENT 'Имя',
  `lastname` varchar(255) NOT NULL COMMENT 'Фамилия',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Хранение данных об администраторах' AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `managers`
--

INSERT INTO `managers` (`id`, `id_user`, `firstname`, `lastname`) VALUES
(1, 1, 'Роман', 'Кротов');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(255) NOT NULL COMMENT 'Логин пользователя',
  `password` varchar(255) NOT NULL COMMENT 'Пароль',
  `email` varchar(255) NOT NULL COMMENT 'Email',
  `level` varchar(255) NOT NULL COMMENT 'уровень доступа',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Хранение основных данных о пользователях' AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `password`, `email`, `level`) VALUES
(1, 'admin', '25d55ad283aa400af464c76d713c07ad', 'drugoisvet@gmail.com', 'Менеджер'),
(5, 'test', '81dc9bdb52d04dc20036dbd8313ed055', 'test@test.ru', 'Партнер');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
