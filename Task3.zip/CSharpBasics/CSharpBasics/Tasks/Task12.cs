﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CSharpBasics.Resource;

namespace CSharpBasics.Tasks
{
    public class Task12 : Task
    {
        public override void Start()
        {
            string resultStr = string.Empty;
            Console.Write("{0} 1: ", Captions.EnterStr);
            string firstStr = Console.ReadLine();
            Console.Write("{0} 2: ", Captions.EnterStr);
            string secondStr = Console.ReadLine();

            foreach (char ch in firstStr)
            {
                if (!secondStr.Contains(ch))
                {
                    resultStr += ch;
                }
                else
                {
                    resultStr += ch;
                    resultStr += ch;
                }
            }

            Console.WriteLine("{0}: {1}", Captions.Result, resultStr);
        }
    }
}

