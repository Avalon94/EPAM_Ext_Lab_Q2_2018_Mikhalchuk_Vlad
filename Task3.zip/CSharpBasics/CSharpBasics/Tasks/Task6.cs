﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CSharpBasics.Resource;

namespace CSharpBasics.Tasks
{
    public class Task6 : Task
    {
        public class Style
        {
            private static string[] styleNameArray =
            {
            Captions.Bold, Captions.Italic, Captions.Underline
        };

            private bool[] styleStateArray = new bool[styleNameArray.Length];

            public static string[] GetStyleNameArray()
            {
                return styleNameArray;
            }

            public bool[] GetStyleStateArray()
            {
                return this.styleStateArray;
            }

            public void Switch(int styleNum)
            {
                try
                {
                    if (this.styleStateArray[styleNum - 1])
                    {
                        this.styleStateArray[styleNum - 1] = false;
                    }
                    else
                    {
                        this.styleStateArray[styleNum - 1] = true;
                    }
                }
                catch (IndexOutOfRangeException)
                {
                    Console.WriteLine(Captions.InputIsIncorrect);
                }
            }

            public override string ToString()
            {
                bool found = false;
                for (int i = 0; i < this.styleStateArray.Length; i++)
                {
                    if (this.styleStateArray[i])
                    {
                        found = true;
                        break;
                    }
                }

                if (!found)
                {
                    return Captions.None;
                }

                string s = string.Empty;
                for (int i = 0; i < this.styleStateArray.Length; i++)
                {
                    if (this.styleStateArray[i])
                    {
                        s += styleNameArray[i] + " ";
                    }
                }

                return s;
            }
        }

        public override void Start()
        {
            Style style = new Style();

            int input = 0;
            do
            {
                Console.WriteLine(Captions.TextStyle + ": " + style.ToString());

                for (int i = 0; i < Style.GetStyleNameArray().Length; i++)
                {
                    Console.WriteLine((i + 1) + " - " + Style.GetStyleNameArray()[i]);
                }

                Console.WriteLine(Captions.Quit);

                int.TryParse(Console.ReadLine(), out input);
                if (input < 0 || input > Style.GetStyleNameArray().Length)
                {
                    Console.WriteLine(Captions.InputIsIncorrect);
                    continue;
                }
                else
                if (input > 0)
                {
                    style.Switch(input);
                }
            }
            while (input != 0);
        }
    }
}
