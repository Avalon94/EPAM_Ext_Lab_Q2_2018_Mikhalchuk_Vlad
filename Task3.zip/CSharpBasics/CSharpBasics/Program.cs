﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CSharpBasics.Tasks;
using CSharpBasics.Resource;

namespace CSharpBasics
{
    class Program
    {
        /// <summary>
        /// Точка входа
        /// </summary>
        /// <param name="args"></param>
        private static List<Tasks.Task> tasksList = new List<Tasks.Task>
        {
            new Task1(),
            new Task2(),
            new Task3(),
            new Task4(),
            new Task5(),
            new Task6(),
            new Task7(),
            new Task8(),
            new Task9(),
            new Task10(),
            new Task11(),
            new Task12(),
            new Task13()
        };

        public static void Main(string[] args)
        {
            int input = 0;
            Console.WriteLine(Captions.SelectTask);
            do
            {
                for (int i = 0; i < tasksList.Count; i++)
                {
                    Console.WriteLine("{0,2} - Task {1}", i + 1, i + 1);
                }

                Console.WriteLine(" {0}", Captions.Quit);

                int.TryParse(Console.ReadLine(), out input);
                if (input < 0 || input > tasksList.Count)
                {
                    Console.WriteLine(Captions.InputIsIncorrect);
                    continue;
                }
                else
                if (input > 0)
                {
                    Console.WriteLine(Captions.Separator);

                    Tasks.Task task = tasksList[input - 1];
                    task.Start();

                    Console.WriteLine(Captions.Separator);
                    Console.WriteLine();
                }
            }
            while (input != 0);
        }
    }
}
